# newpackage
This library contains one module for sorting and one module for recursion.

## building this package locally
`python setup.py sdist `

## installing this package from GitHub
`pip install git+"https://github.com/EBIMASTER117/newpackage"`

## updating this package from GitHub
`pip install --upgrade git+"https://github.com/EBIMASTER117/newpackage"`
